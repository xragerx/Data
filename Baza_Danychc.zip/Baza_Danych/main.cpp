#include <iostream>

using namespace std;

class cWezel
{
public:
    int mLiczba;
    cWezel* mNastepny;
    cWezel();
    cWezel(int aLiczba);
};

class cBaza
{
public:
    cWezel* mPierwszy;
    cBaza();
    void Dodaj(int aLiczba);
    void Pokaz();
};
cWezel::cWezel()
{
    mLiczba=0;
    mNastepny=nullptr;
}
cBaza::cBaza()
{
    mPierwszy=nullptr;
}
void cBaza::Dodaj(int aLiczba)
{
    cWezel* lacznik=mPierwszy;
    mPierwszy=new cWezel(aLiczba);
    mPierwszy->mNastepny=lacznik;
}
cWezel::cWezel(int aLiczba):mLiczba(aLiczba)
{
    mNastepny=nullptr;
}
void cBaza::Pokaz()
{
    cWezel* lacznik=mPierwszy;
    while(lacznik!=nullptr)
    {
        cout<<lacznik->mLiczba<<endl;
        lacznik=lacznik->mNastepny;
    }
}
int main()
{
    cBaza db1;
    db1.Dodaj(5);
    db1.Dodaj(7);
    db1.Pokaz();
    return 0;
}
